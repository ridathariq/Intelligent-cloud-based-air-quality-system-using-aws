
import { useEffect, useRef, useState } from 'react';
import {
  CATEGORIES, ALERT_THRESHOLD, BUZZER_THRESHOLD,
  adcToPpm, adcToVoltage, ppmToAqi, aqiToAdc, getCategory,
} from '../lib/aqi';

// If VITE_API_URL is set the dashboard runs in LIVE mode, otherwise DEMO mode.
const LIVE_URL = import.meta.env.VITE_API_URL || '';
const TICK_MS = 1000;
const HISTORY_LIMIT = 40;
const LOG_LIMIT = 30;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const rand = (lo, hi) => lo + Math.random() * (hi - lo);

// ---- Demo-mode sensor simulator ------------------------------------------
function stepSimulation(sim, mode) {
  let lo = 0;
  let hi = 500;

  if (mode === 'auto') {
    sim.countdown -= 1;
    if (sim.countdown <= 0) {
      sim.target = rand(20, 380);
      sim.countdown = Math.round(rand(15, 30));
    }
  } else {
    const band = CATEGORIES.find((c) => c.key === mode);
    sim.target = (band.min + band.max) / 2;
    lo = band.min;
    hi = band.max;
  }

  const noise = (Math.random() - 0.5) * 14;
  sim.value = clamp(
    sim.value + (sim.target - sim.value) * 0.25 + noise,
    lo,
    hi
  );

  return aqiToAdc(sim.value);
}

// ---- Live-mode reader -----------------------------------------------------
async function fetchAdc() {
  const res = await fetch(LIVE_URL);

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }

  let data = await res.json();

  // Handle Lambda responses that wrap the result in "body".
  if (data && typeof data.body === 'string') {
    data = JSON.parse(data.body);
  } else if (data?.body && typeof data.body === 'object') {
    data = data.body;
  }

  // Convert an array response into its first reading.
  // The API should return the newest reading first.
  if (Array.isArray(data)) {
    data = data[0];
  }

  // Handle common response wrappers such as items, readings or data.
  // Also supports a direct response such as { adc: 1093 }.
  for (let i = 0; i < 4 && data && typeof data === 'object'; i++) {
    if (
      data.adc != null ||
      data.aqi != null ||
      data.gas_value != null
    ) {
      break;
    }

    const nested =
      data.latest ??
      data.item ??
      data.items ??
      data.readings ??
      data.data;

    if (nested == null) {
      break;
    }

    data = Array.isArray(nested) ? nested[0] : nested;
  }

  if (!data || typeof data !== 'object') {
    throw new Error('No reading returned by API');
  }

  // Accept numbers or numeric strings from DynamoDB/API responses.
  const toNumber = (value) => {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };

  // Prefer the actual ADC/raw sensor reading.
  const adc = toNumber(data.adc ?? data.gas_value);

  if (adc !== null) {
    return adc;
  }

  // If the API provides AQI instead, convert it for the existing dashboard logic.
  const aqi = toNumber(data.aqi);

  if (aqi !== null) {
    return aqiToAdc(aqi);
  }

  throw new Error(
    'Unexpected API response: expected adc, gas_value, or aqi'
  );
}

export function useAirQuality() {
  const [mode, setMode] = useState('auto');
  const [fastDemo, setFastDemo] = useState(false);
  const [snapshot, setSnapshot] = useState(null);

  // Refs let the interval read the latest settings without restarting.
  const modeRef = useRef(mode);
  const fastRef = useRef(fastDemo);
  modeRef.current = mode;
  fastRef.current = fastDemo;

  const sim = useRef({ value: 130, target: 140, countdown: 20 });

  // This mirrors what the Lambda + ESP32 do: persistence timer, LED, buzzer.
  const machine = useRef({
    secondsAbove: 0,
    alertActive: false,
    buzzer: false,
  });

  useEffect(() => {
    let cancelled = false;

    const tick = async () => {
      let adc;

      try {
        adc = LIVE_URL
          ? await fetchAdc()
          : stepSimulation(sim.current, modeRef.current);
      } catch (error) {
        console.error('Air quality API error:', error);

        if (!cancelled) {
          setSnapshot((p) => (p ? { ...p, online: false } : p));
        }

        return;
      }

      if (cancelled) return;

      const now = new Date();
      const time = now.toLocaleTimeString('en-US');
      const ppm = adcToPpm(adc);
      const aqi = ppmToAqi(ppm);
      const limit = fastRef.current ? 10 : 15;
      const m = machine.current;
      const events = [];

      // 1. Persistence timer: counts seconds while AQI stays above 200.
      if (aqi > ALERT_THRESHOLD) {
        if (m.secondsAbove === 0) {
          events.push({
            tone: 'warn',
            text: `AQI ${aqi} crossed ${ALERT_THRESHOLD}. Persistence timer started.`,
          });
        }

        m.secondsAbove = Math.min(m.secondsAbove + 1, limit);
      } else {
        if (m.alertActive) {
          events.push({
            tone: 'ok',
            text: `AQI back to ${aqi}. Alert cleared, red LED and buzzer off.`,
          });
        } else if (m.secondsAbove > 0) {
          events.push({
            tone: 'info',
            text: `AQI fell to ${aqi} before ${limit} s. Timer reset.`,
          });
        }

        m.secondsAbove = 0;
        m.alertActive = false;
        m.buzzer = false;
      }

      // 2. Alert fires only after AQI stays high for the full limit.
      if (
        aqi > ALERT_THRESHOLD &&
        m.secondsAbove >= limit &&
        !m.alertActive
      ) {
        m.alertActive = true;
        events.push({
          tone: 'alert',
          text: `AQI above ${ALERT_THRESHOLD} for ${limit} s. Red LED on.`,
        });
      }

      // 3. Buzzer: active alert AND AQI above 300.
      const buzzerNow = m.alertActive && aqi > BUZZER_THRESHOLD;

      if (buzzerNow && !m.buzzer) {
        events.push({
          tone: 'alert',
          text: `AQI ${aqi} above ${BUZZER_THRESHOLD}. Buzzer on.`,
        });
      }

      if (!buzzerNow && m.buzzer && m.alertActive) {
        events.push({
          tone: 'info',
          text: `AQI ${aqi} below ${BUZZER_THRESHOLD}. Buzzer off.`,
        });
      }

      m.buzzer = buzzerNow;

      const leds = {
        green: !m.alertActive && aqi <= 50,
        yellow: !m.alertActive && aqi > 50,
        red: m.alertActive,
      };

      const state = {
        secondsAbove: m.secondsAbove,
        alertActive: m.alertActive,
        buzzer: m.buzzer,
      };

      setSnapshot((prev) => ({
        adc,
        ppm,
        aqi,
        time,
        limit,
        leds,
        ...state,
        voltage: adcToVoltage(adc),
        category: getCategory(aqi),
        online: true,
        history: [
          ...(prev?.history ?? []),
          { ts: now.getTime(), time, aqi },
        ].slice(-HISTORY_LIMIT),
        log: [
          ...events
            .map((e, i) => ({
              ...e,
              time,
              id: `${now.getTime()}-${i}`,
            }))
            .reverse(),
          ...(prev?.log ?? []),
        ].slice(0, LOG_LIMIT),
      }));
    };

    tick();

    const id = setInterval(tick, TICK_MS);

    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  return {
    mode,
    setMode,
    fastDemo,
    setFastDemo,
    snapshot,
    isLive: Boolean(LIVE_URL),
  };
}
