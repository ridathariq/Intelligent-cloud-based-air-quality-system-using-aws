export default function Header({ isLive, limit, updated }) {
  return (
    <header className="header">
      <div className="header__title">
        <h1>Intelligent Cloud-Based Air Quality Alert System</h1>
        <p>Cloud Computing and IoT | M.Tech CSE | CUSAT</p>
      </div>
      <div className="header__pills">
        <span className="pill">{isLive ? 'Live mode' : 'Demo mode'}</span>
        <span className="pill">Persistence {limit} s</span>
        <span className="pill">Updated {updated}</span>
      </div>
    </header>
  );
}
