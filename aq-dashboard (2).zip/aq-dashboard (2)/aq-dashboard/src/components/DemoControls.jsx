const MODES = [
  ['auto', 'Auto'],
  ['good', 'Good'],
  ['satisfactory', 'Satisfactory'],
  ['moderate', 'Moderate'],
  ['poor', 'Poor'],
  ['dangerous', 'Dangerous'],
];

// Lets you force any AQI band while presenting, and shorten the timer.
export default function DemoControls({ mode, setMode, fastDemo, setFastDemo }) {
  return (
    <section className="demo">
      <div className="demo__modes">
        <strong>Demo controls</strong>
        {MODES.map(([key, label]) => (
          <button
            key={key}
            type="button"
            className={`btn ${mode === key ? 'btn--active' : ''}`}
            aria-pressed={mode === key}
            onClick={() => setMode(key)}
          >
            {label}
          </button>
        ))}
      </div>
      <label className="demo__fast">
        <input type="checkbox" checked={fastDemo} onChange={(e) => setFastDemo(e.target.checked)} />
        Fast demo (10 s persistence)
      </label>
    </section>
  );
}
