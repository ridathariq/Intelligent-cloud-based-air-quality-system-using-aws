// Shows the cloud data path. Amber dots = simulated (demo), green = live.
const STAGES = [
  ['ESP32 + MQ135', 'MQTT uplink'],
  ['AWS IoT Core', 'Broker'],
  ['AWS Lambda', 'AQI + persistence'],
  ['DynamoDB', 'History'],
  ['API Gateway', 'REST APIs'],
  ['S3 Dashboard', 'React UI'],
];

export default function PipelineStatus({ isLive, online }) {
  const dot = isLive ? (online ? '#16a34a' : '#dc2626') : '#f59e0b';
  return (
    <article className="card card--wide">
      <h2>Data Pipeline Status</h2>
      <div className="pipeline">
        {STAGES.map(([name, note], i) => (
          <span className="chip" key={name}>
            <span className="chip__dot" style={{ background: dot }} />
            <strong>{name}</strong>
            <span className="chip__note">{note}</span>
            {i < STAGES.length - 1 && <span className="chip__arrow">&rarr;</span>}
          </span>
        ))}
      </div>
      <p className="small muted">
        {isLive
          ? online ? 'Live mode: readings are coming from the API.' : 'Live mode: the API is not responding.'
          : 'Demo mode: cloud services are simulated in the browser.'}
      </p>
    </article>
  );
}
