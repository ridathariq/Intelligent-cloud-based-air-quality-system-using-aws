import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  ReferenceArea, ReferenceLine, ResponsiveContainer,
} from 'recharts';

// Coloured bands behind the line mirror the AQI categories.
const BANDS = [
  { y1: 0, y2: 100, fill: '#16a34a' },
  { y1: 100, y2: 200, fill: '#ca8a04' },
  { y1: 200, y2: 300, fill: '#ea580c' },
  { y1: 300, y2: 500, fill: '#dc2626' },
];

export default function HistoryChart({ history }) {
  const values = history.map((p) => p.aqi);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);

  return (
    <article className="card card--wide">
      <div className="card__head">
        <h2>AQI History</h2>
        <div className="stats">
          <span>Min <strong>{min}</strong></span>
          <span>Average <strong>{avg}</strong></span>
          <span>Max <strong>{max}</strong></span>
        </div>
      </div>
      <div className="chart">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={history} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
            {BANDS.map((b) => (
              <ReferenceArea key={b.y1} y1={b.y1} y2={b.y2} fill={b.fill} fillOpacity={0.1} ifOverflow="hidden" />
            ))}
            <CartesianGrid strokeDasharray="4 4" stroke="#94a3b8" strokeOpacity={0.55} />
            <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#475569' }} minTickGap={36} stroke="#64748b" />
            <YAxis domain={[0, 500]} ticks={[0, 150, 300, 500]} tick={{ fontSize: 14, fill: '#475569' }} stroke="#64748b" width={44} />
            <ReferenceLine
              y={200} stroke="#ef4444" strokeDasharray="5 4"
              label={{ value: 'Alert threshold 200', position: 'center', fill: '#ef4444', fontSize: 10 }}
            />
            <Line type="monotone" dataKey="aqi" stroke="#1e3a5f" strokeWidth={2.2} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </article>
  );
}
