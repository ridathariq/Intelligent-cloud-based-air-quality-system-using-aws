import { CATEGORIES } from '../lib/aqi';

// The row for the current AQI band is highlighted.
export default function ScaleTable({ currentKey }) {
  return (
    <article className="card">
      <h2>AQI Scale and System Response</h2>
      <table className="scale">
        <thead>
          <tr><th>AQI</th><th>Category</th><th>Response</th></tr>
        </thead>
        <tbody>
          {CATEGORIES.map((c) => (
            <tr key={c.key} className={c.key === currentKey ? 'scale__current' : ''}>
              <td><span className="swatch" style={{ background: c.color }} />{c.range}</td>
              <td>{c.label}</td>
              <td>{c.response}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </article>
  );
}
