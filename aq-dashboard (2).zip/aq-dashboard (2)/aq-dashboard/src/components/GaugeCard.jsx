// Semi-circle gauge drawn with SVG arcs. The arc runs from the left (AQI 0)
// over the top to the right (AQI 500).
const R = 110;
const CX = 150;
const CY = 150;

export default function GaugeCard({ aqi, category }) {
  const frac = Math.min(Math.max(aqi / 500, 0), 1);
  const angle = Math.PI * (1 - frac);
  const x = CX + R * Math.cos(angle);
  const y = CY - R * Math.sin(angle);

  const track = `M ${CX - R} ${CY} A ${R} ${R} 0 0 1 ${CX + R} ${CY}`;
  const value = `M ${CX - R} ${CY} A ${R} ${R} 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)}`;

  return (
    <article className="card">
      <h2>Live AQI</h2>
      <svg className="gauge" viewBox="0 0 300 200" role="img" aria-label={`AQI ${aqi}, ${category.label}`}>
        <path d={track} className="gauge__track" />
        {frac > 0 && <path d={value} stroke={category.color} className="gauge__value" />}
        <text x={CX} y="148" textAnchor="middle" className="gauge__number">{aqi}</text>
        <text x={CX} y="180" textAnchor="middle" className="gauge__label" fill={category.color}>
          {category.label}
        </text>
        <text x={CX - R} y="182" textAnchor="middle" className="gauge__end">0</text>
        <text x={CX + R} y="182" textAnchor="middle" className="gauge__end">500</text>
      </svg>
    </article>
  );
}
