// Virtual copy of the ESP32 outputs: three LEDs, a buzzer and the timer bar.
const LEDS = [
  { key: 'green', label: 'Green', color: '#16a34a', glow: 'rgba(22,163,74,.55)' },
  { key: 'yellow', label: 'Yellow', color: '#eab308', glow: 'rgba(234,179,8,.6)' },
  { key: 'red', label: 'Red', color: '#dc2626', glow: 'rgba(220,38,38,.55)' },
];

export default function AlertOutputCard({ leds, buzzer, secondsAbove, limit }) {
  const pct = Math.min((secondsAbove / limit) * 100, 100);
  return (
    <article className="card">
      <h2>ESP32 Alert Output</h2>
      <div className="outputs">
        {LEDS.map((led) => (
          <div className="outputs__item" key={led.key}>
            <span
              className="led"
              style={leds[led.key] ? { background: led.color, boxShadow: `0 0 14px ${led.glow}` } : undefined}
              aria-label={`${led.label} LED ${leds[led.key] ? 'on' : 'off'}`}
            />
            <span>{led.label}</span>
          </div>
        ))}
        <div className="outputs__item">
          <span className={`buzzer ${buzzer ? 'buzzer--on' : ''}`}>{buzzer ? 'ON' : 'OFF'}</span>
          <span>Buzzer</span>
        </div>
      </div>
      <p className="small muted">Persistence timer (AQI above 200)</p>
      <div className="bar">
        <div className="bar__fill" style={{ width: `${pct}%`, background: secondsAbove >= limit ? '#dc2626' : '#eab308' }} />
      </div>
      <p className="small"><strong>{secondsAbove} s</strong> / {limit} s</p>
    </article>
  );
}
