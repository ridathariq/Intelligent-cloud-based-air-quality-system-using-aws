// Full-width status strip. Colour comes from the current AQI band; the badge
// shows OK / WARN (timer running) / ALERT (persistence reached).
export default function AlertBanner({ category, secondsAbove, alertActive, aqi }) {
  const { tone, message } = category;
  let badge = 'OK';
  let text = message;
  if (alertActive) {
    badge = 'ALERT';
    text = `${category.label}: Alert active. Red LED${aqi > 300 ? ' and buzzer are' : ' is'} on. Ventilate now.`;
  } else if (secondsAbove > 0) {
    badge = 'WARN';
  }
  return (
    <section
      className="banner"
      role="status"
      style={{ background: tone.bg, borderColor: tone.border, color: tone.text }}
    >
      <span className="banner__badge">{badge}</span>
      <strong>{text}</strong>
    </section>
  );
}
