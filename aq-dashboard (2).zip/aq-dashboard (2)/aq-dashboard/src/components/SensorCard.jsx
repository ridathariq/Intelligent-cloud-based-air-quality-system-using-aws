export default function SensorCard({ adc, voltage, ppm, aqi }) {
  const rows = [
    ['ADC (12-bit)', adc, '0-4095'],
    ['Voltage', `${voltage.toFixed(2)} V`, '0-3.3 V'],
    ['Concentration', `${ppm} ppm`, '0-1000 ppm'],
    ['AQI', aqi, '0-500'],
  ];
  return (
    <article className="card">
      <h2>Sensor Reading (MQ135)</h2>
      <table className="sensor-table">
        <tbody>
          {rows.map(([label, value, range]) => (
            <tr key={label}>
              <td>{label}</td>
              <td className="sensor-table__value">{value}</td>
              <td className="muted">{range}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="formula">V = ADC / 4095 x 3.3 &nbsp;&nbsp; C = ADC / 4095 x 1000</p>
    </article>
  );
}
