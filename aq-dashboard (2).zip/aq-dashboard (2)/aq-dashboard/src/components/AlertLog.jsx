const DOT = { alert: '#dc2626', warn: '#f59e0b', ok: '#16a34a', info: '#64748b' };

export default function AlertLog({ log }) {
  return (
    <article className="card">
      <h2>Alert Log</h2>
      {log.length === 0 ? (
        <p className="muted small">No events yet. Alerts appear here.</p>
      ) : (
        <ul className="log">
          {log.map((e) => (
            <li key={e.id}>
              <span className="log__dot" style={{ background: DOT[e.tone] }} />
              <span className="log__time">{e.time}</span>
              <span>{e.text}</span>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}
