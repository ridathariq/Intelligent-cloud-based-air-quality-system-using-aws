import { useAirQuality } from './hooks/useAirQuality';
import Header from './components/Header';
import AlertBanner from './components/AlertBanner';
import GaugeCard from './components/GaugeCard';
import SensorCard from './components/SensorCard';
import AlertOutputCard from './components/AlertOutputCard';
import HistoryChart from './components/HistoryChart';
import ScaleTable from './components/ScaleTable';
import AlertLog from './components/AlertLog';
import PipelineStatus from './components/PipelineStatus';
import DemoControls from './components/DemoControls';

export default function App() {
  const { mode, setMode, fastDemo, setFastDemo, snapshot: s, isLive } = useAirQuality();

  // First tick has not arrived yet.
  if (!s) return <main className="page"><p className="muted">Connecting to sensor...</p></main>;

  return (
    <main className="page">
      <Header isLive={isLive} limit={s.limit} updated={s.time} />
      <AlertBanner category={s.category} secondsAbove={s.secondsAbove} alertActive={s.alertActive} aqi={s.aqi} />

      <div className="grid-3">
        <GaugeCard aqi={s.aqi} category={s.category} />
        <SensorCard adc={s.adc} voltage={s.voltage} ppm={s.ppm} aqi={s.aqi} />
        <AlertOutputCard leds={s.leds} buzzer={s.buzzer} secondsAbove={s.secondsAbove} limit={s.limit} />
      </div>

      <HistoryChart history={s.history} />

      <div className="grid-2">
        <ScaleTable currentKey={s.category.key} />
        <AlertLog log={s.log} />
      </div>

      <PipelineStatus isLive={isLive} online={s.online} />

      {!isLive && (
        <DemoControls mode={mode} setMode={setMode} fastDemo={fastDemo} setFastDemo={setFastDemo} />
      )}
    </main>
  );
}
